﻿var Server = {
    request: function (ptype, purl, pdata, psuccess, pfailure, perror) {// Hàm dùng ajax để gửi request lên server
        jQuery.ajax({
            type: ptype,
            url: purl,
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(pdata),
            success: function (response) {
                psuccess(response);
            },
            failure: function (response) {
                pfailure(response);
            },
            error: function (response) {
                perror(response);
            },
        });
    }    
}
class PTag {
    constructor(_text) {
        this.txt = _text;
    }
    _getTag() {        
        return "<p class='p-tag'><i class=\"glyphicon - search\"></i><button>{txt}</button></p>".replace("{txt}",this.txt);
    }
    _getKeyTag(){
        return "<p class='p-tag p-key-tag'><i class=\"glyphicon - search\"></i><button>{txt}</button></p>".replace("{txt}",this.txt);
    }
}
class DivTag {
    constructor(_id) {
        this.id = _id;
    }
    _callServer(_key) {
        var root = this;
        Server.request("POST","/Home/Search",{key:_key},function(response){
            if(response.status)
                root._renderText(_key,response.data);
            else{
                root._renderText(_key,[]);
            }                
        },function(response){

        },function(response){

        });
    }
    _renderText(_key,_arr) {
        this._emptyText();
        var html = "";
        html+= new PTag(_key)._getKeyTag();
        $.each(_arr,function(index,elm){
            html+= new PTag(elm)._getTag();
        });
        $(this.id).append(html);                
    }
    _emptyText(){
        $(this.id).empty();
    }
}
function _init(){
    var jker = new DivTag("#jker");
    var jkerElement = $("#jker");
    var input = $("#input");    
    $(input).bind('input',function(evt,ui){
        if($(input).val().trim()!="")
            jker._callServer($(input).val());
        else
            jker._emptyText();
    });
    jkerElement.click(function(evt){
        if(evt.target.nodeName=="BUTTON"){
            input.val(evt.target.innerHTML);
            jker._emptyText();
        }
    });
    jkerElement.mousemove(function(evt){
        var btnLst = $("#jker button");
        $.each(btnLst,function(index,elm){
            elm.className=elm.className.replace(" btn-hover","");
        });        
        if(evt.target.nodeName=="BUTTON"){
            evt.target.className+=" btn-hover";
        }
    });
}
_init();