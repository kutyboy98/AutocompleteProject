﻿using Autocomplete.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Autocomplete.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ContentResult Search(string key)
        {
            if (key.Trim().ToLower().Equals("iphone"))
            {
                List<string> data = new List<string>();
                data.Add("iphone 4");
                data.Add("iphone 5");
                data.Add("iphone 6");
                data.Add("iphone 7");
                data.Add("iphone 7 plus");
                data.Add("iphone 8");
                data.Add("iphone X");
                return Content(Data.ToJson(new DataReponse { status = true,data = data }));
            }
            else if (key.Trim().ToLower().Equals("samsung")|| key.Trim().ToLower().Equals("sam"))
            {
                List<string> data = new List<string>();
                data.Add("samsung gear");
                data.Add("samsung galaxy s6");
                data.Add("samsung galaxy s7");
                data.Add("samsung galaxy s7 edge");
                return Content(Data.ToJson(new DataReponse { status = true, data = data }));
            }
            return Content(Data.ToJson(new DataReponse { status = false}));
        }
    }
}