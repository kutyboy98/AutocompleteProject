﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Autocomplete.Models
{
    public class DataReponse
    {
        public string mess { get; set; }
        public bool status { get; set; }
        public object data { get; set; }
        public string exception { get; set; }
    }
    public class Data
    {
        public static string ToJson(object data)
        {
            var res = JsonConvert.SerializeObject(data, Formatting.None,
                   new JsonSerializerSettings() { ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore });
            return res;
        }
    }
}